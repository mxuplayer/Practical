const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function printMultiplicationTable(num) {
  console.log(`Multiplication table for ${num}:`);
  for (let i = 1; i <= 10; i++) {
    console.log(`${num} x ${i} = ${num * i}`);
  }
}

function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

function isPalindrome(str) {
  const cleanStr = str.toLowerCase().replace(/[^a-z0-9]/g, '');
  const reversedStr = cleanStr.split('').reverse().join('');
  return cleanStr === reversedStr;
}

rl.question('Enter a number for the multiplication table: ', (num) => {
  process.nextTick(() => {
    printMultiplicationTable(parseInt(num));
  });

  setImmediate(() => {
    rl.question('Enter a year to check for leap year: ', (year) => {
      if (isLeapYear(parseInt(year))) {
        console.log(`${year} is a leap year.`);
      } else {
        console.log(`${year} is not a leap year.`);
      }

      setTimeout(() => {
        rl.question('Enter a string to check for palindrome: ', (str) => {
          if (isPalindrome(str)) {
            console.log(`"${str}" is a palindrome.`);
          } else {
            console.log(`"${str}" is not a palindrome.`);
          }
          rl.close();
        });
      }, 0);
    });
  });
});
