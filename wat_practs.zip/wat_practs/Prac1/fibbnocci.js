const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Enter the number of Fibonacci numbers to generate: ', (input) => {
  const n = parseInt(input);

  if (isNaN(n) || n <= 0) {
    console.log('Please enter a valid positive number.');
    rl.close();
  } else {
    let fibArray = [0, 1];

    for (let i = 2; i < n; i++) {
      const nextFib = fibArray[i - 1] + fibArray[i - 2];
      fibArray.push(nextFib);
    }

    console.log(`First ${n} Fibonacci numbers:`);
    console.log(fibArray.join(', '));

    rl.close();
  }
});
