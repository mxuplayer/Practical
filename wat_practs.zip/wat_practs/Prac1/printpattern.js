const numRows = 5;

for (let i = numRows; i >= 1; i--) {
  let pattern = '';
  for (let j = 1; j <= i; j++) {
    pattern += j + ' ';
  }
  console.log(pattern.trim());
}



