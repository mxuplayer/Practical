let http = require('http');''

const requestListener = function (req, res) {
res.setHeader("Content-Type", "text/csv");
res.setHeader("Content-Disposition", "attachment;filename = cricket.csv");
res.writeHead(200);
res.write('id, name, email \n1, Rohit Sharma, sharma@cricket.com \n2, Virat Kohli, virat@cricket.com');
res.end();
};

http.createServer(requestListener).listen(5000);

