const http = require('http');
const fs = require('fs');

const server = http.createServer(function(req, res) {
  res.writeHead(200, { 'Content-Type': 'video/mp4' });

  const rs = fs.createReadStream('test.mp4');
  rs.pipe(res);
});

server.listen(8001, () => {
  console.log('Server is running on port 8001');
});
