var http = require('http');

var server = http.createServer (function(req, res) {
    if (req.url == '/') { 
        res.writeHead (200, {'Content-Type': 'text/html' });
        res.write('<html><head><title>Home Page</title></head><body><p><strong>Welcome to Vivekanand Education Society&apos;s Institute of Technology (MCA Department)</strong></p></body></html>'); 
        res.end();
    } 
    else if (req.url == "/aboutme") {
        res.writeHead (200, {'Content-Type': 'text/html' }); 
        res.write('<html><head><title>About Me</title></head><body><p><strong>Hello Myself, "Pradeep Vahatule"</strong></p></body></html>'); 
        res.end();
    } 
    else if (req.url == "/contact") {
        res.writeHead (200, {'Content-Type': 'text/html' }); 
        res.write('<html><head><title>Contact</title></head><body><p><strong>College Email ID - 2023.pradeep.vahatule@ves.ac.in</strong></p></body></html>'); 
        res.end();
    }
    else
        res.end('Invalid Request!');
    });

server.listen(8003);