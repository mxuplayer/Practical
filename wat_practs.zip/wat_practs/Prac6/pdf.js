let http = require('http');
let fs = require('fs');
const path = require('path');

const requestListener = function (req, res) {
  const filePath = path.join(__dirname, 'dummy.pdf'); // Assuming "dummy.pdf" is in the same directory as your JavaScript file
  const fileStream = fs.createReadStream(filePath);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", "attachment;filename=dummy.pdf");

  fileStream.pipe(res);

  fileStream.on('error', (err) => {
    console.error(err);
    res.statusCode = 500;
    res.end("Internal Server Error");
  });
};

http.createServer(requestListener).listen(8000);
