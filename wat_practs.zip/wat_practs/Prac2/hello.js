function hello() {
    console.log("Hello");
}

var myint = setInterval(hello,500);

setTimeout (function() {clearInterval(myint)}, 5500);
