var cust = require('./calculate.js')

var prompt = require('prompt-sync')();

var a = parseInt(prompt("Enter first number : "));
var b = parseInt(prompt("Enter second number : "));

console.log()
console.log("Select your choice Accordingly...")
console.log("1 : Add two numbers")
console.log("2 : Subtract two numbers")
console.log("3 : Multiply two numbers")
console.log("4 : Divide two numbers")
console.log("5 : Modulus of two numbers")

var c = parseInt(prompt("Enter your choice : "));

switch(c){
    case 1:
        console.log(cust.add(a, b));
    break;

    case 2:
        console.log(cust.subtract(a, b));
    break;

    case 3:
    console.log(cust.multiply(a, b));
    break;

    case 4:
    console.log(cust.division(a, b));
    break;

    case 5:
    console.log(cust.modulus(a, b));
    break;

    default:
        console.log("Invalid Input");
    break;
}
