exports.message = "Hello Pradeep!"

exports.add = function(a, b){
    return(a + b);
}

exports.subtract = function(a, b){
    return(a - b);
}

exports.multiply = function(a, b){
    return(a * b);
}

exports.division = function(a, b){
    if(b == 0){
        console.log("Division by Zero Error")
    }
    else{
        return(a / b);
    }    
}

exports.modulus = function(a, b){
    return(a % b);
}
