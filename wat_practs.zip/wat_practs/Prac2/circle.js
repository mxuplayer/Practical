exports.area = function(r){
    return("Area of circle with radius " + r + " is " + 3.14 * r * r);
}

exports.perimeter = function(r){
    return("Perimeter of circle with radius " + r + " is " + 2 * 3.14 * r);
}

