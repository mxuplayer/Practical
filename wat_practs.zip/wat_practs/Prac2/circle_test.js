var circle = require('./circle.js')

var prompt = require('prompt-sync')();

var radius = parseInt(prompt("Enter radius of circle : "));

console.log(circle.area(radius));
console.log(circle.perimeter(radius));
