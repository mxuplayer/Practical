var mysql = require('mysql2');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '@prad#15',
    database: "vesit"
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

var sql_c = "CREATE TABLE student (rollno int(5), name VARCHAR(25), address VARCHAR(75))";
connection.query(sql_c, (err, results) => {
    if (err) throw err;
    console.log('Table Created');
});

var sql_i = "INSERT INTO student (rollno,name,address) VALUES ?";
var values = [[56, 'Pradeep', 'Ambivali'], [42, 'Aniket', 'Kalyan'], [38, 'Mayur', 'Nashik'], [32, 'Shubham', 'Chembur']];
connection.query(sql_i, [values], (err, results) => {
    if (err) throw err;
    console.log(`Records Inserted`, results.affectedRows);
});

var sql_s = "SELECT * FROM student";
connection.query(sql_s, (err, results) => {
    if (err) throw err;
    console.log(results);
});

const roll_u = 38;
var sql_u = "UPDATE student SET address ='Mumbai' WHERE rollno = '38'";
connection.query(sql_u, (err, results) => {
    if (err) throw err;
    console.log('Updated Student with rollno ', roll_u);
});

var sql_s = "SELECT * FROM student";
connection.query(sql_s, (err, results) => {
    if (err) throw err;
    console.log(results);
});

const roll_d = 32;
connection.query('DELETE FROM student WHERE rollno = ?', roll_d, (err, results) => {
    if (err) throw err;
    console.log(`Deleted Student with rollno `, roll_d);
});

var sql_s = "SELECT * FROM student";
connection.query(sql_s, (err, results) => {
    if (err) throw err;
    console.log(results);
});

connection.end((err) => {
    if (err) {
        console.error('Error closing the connection:', err);
        return;
    }
    console.log('Disconnected from MySQL');
});
