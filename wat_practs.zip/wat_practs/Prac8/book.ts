class Book {
    private books: {
      bookId: number;
      bookName: string;
      author: string;
      isbn: string;
      publisher: string;
    }[] = [];
  
    constructor() {
      // You can initialize some books in the constructor for demonstration purposes.
      this.addBook(1, 'Book 1', 'Author 1', 'ISBN-001', 'Publisher A');
      this.addBook(2, 'Book 2', 'Author 2', 'ISBN-002', 'Publisher B');
      this.addBook(3, 'Book 3', 'Author 3', 'ISBN-003', 'Publisher C');
      this.addBook(4, 'Book 4', 'Author 4', 'ISBN-004', 'Publisher D');
      this.addBook(5, 'Book 5', 'Author 5', 'ISBN-005', 'Publisher E');
    }
  
    addBook(bookId: number, bookName: string, author: string, isbn: string, publisher: string) {
      this.books.push({ bookId, bookName, author, isbn, publisher });
    }
  
    displayBooks() {
      console.log('List of Books:');
      this.books.forEach((book) => {
        console.log(`Book ID: ${book.bookId}`);
        console.log(`Book Name: ${book.bookName}`);
        console.log(`Author: ${book.author}`);
        console.log(`ISBN No: ${book.isbn}`);
        console.log(`Publisher: ${book.publisher}`);
        console.log('------------------------');
      });
    }
  
    searchBookById(bookId: number) {
      let foundBook = null;
  
      for (const book of this.books) {
        if (book.bookId === bookId) {
          foundBook = book;
          break;
        }
      }
  
      if (foundBook) {
        console.log('Book Found:');
        console.log(`Book ID: ${foundBook.bookId}`);
        console.log(`Book Name: ${foundBook.bookName}`);
        console.log(`Author: ${foundBook.author}`);
        console.log(`ISBN No: ${foundBook.isbn}`);
        console.log(`Publisher: ${foundBook.publisher}`);
      } else {
        console.log(`Book with ID ${bookId} not found.`);
      }
  }
  
  }
  
  const library = new Book();
  
  library.displayBooks();
  
  // Example of searching for a book by Book ID
  library.searchBookById(3); // Change the ID to search for a different book
  