var Book = /** @class */ (function () {
    function Book() {
        this.books = [];
        // You can initialize some books in the constructor for demonstration purposes.
        this.addBook(1, 'Book 1', 'Author 1', 'ISBN-001', 'Publisher A');
        this.addBook(2, 'Book 2', 'Author 2', 'ISBN-002', 'Publisher B');
        this.addBook(3, 'Book 3', 'Author 3', 'ISBN-003', 'Publisher C');
        this.addBook(4, 'Book 4', 'Author 4', 'ISBN-004', 'Publisher D');
        this.addBook(5, 'Book 5', 'Author 5', 'ISBN-005', 'Publisher E');
    }
    Book.prototype.addBook = function (bookId, bookName, author, isbn, publisher) {
        this.books.push({ bookId: bookId, bookName: bookName, author: author, isbn: isbn, publisher: publisher });
    };
    Book.prototype.displayBooks = function () {
        console.log('List of Books:');
        this.books.forEach(function (book) {
            console.log("Book ID: ".concat(book.bookId));
            console.log("Book Name: ".concat(book.bookName));
            console.log("Author: ".concat(book.author));
            console.log("ISBN No: ".concat(book.isbn));
            console.log("Publisher: ".concat(book.publisher));
            console.log('------------------------');
        });
    };
    Book.prototype.searchBookById = function (bookId) {
        var foundBook = null;
        for (var _i = 0, _a = this.books; _i < _a.length; _i++) {
            var book = _a[_i];
            if (book.bookId === bookId) {
                foundBook = book;
                break;
            }
        }
        if (foundBook) {
            console.log('Book Found:');
            console.log("Book ID: ".concat(foundBook.bookId));
            console.log("Book Name: ".concat(foundBook.bookName));
            console.log("Author: ".concat(foundBook.author));
            console.log("ISBN No: ".concat(foundBook.isbn));
            console.log("Publisher: ".concat(foundBook.publisher));
        }
        else {
            console.log("Book with ID ".concat(bookId, " not found."));
        }
    };
    return Book;
}());
var library = new Book();
library.displayBooks();
// Example of searching for a book by Book ID
library.searchBookById(3); // Change the ID to search for a different book
