const EventEmitter = require('events');

const eventEmitter = new EventEmitter();

const myFirstEventHandler = function () {
  console.log('Hello First Event');
};

const mysecondEventHandler = function () {
  console.log('Hello Second Event');
};

eventEmitter.addListener('MyEvent', myFirstEventHandler);
eventEmitter.on('MyEvent', mysecondEventHandler);
eventEmitter.once('MyEventOnce', () => {
  console.log('This will only be triggered once!');
});

eventEmitter.emit('MyEvent');
eventEmitter.emit('MyEventOnce');

eventEmitter.setMaxListeners(15);
console.log('Max Listeners:', eventEmitter.getMaxListeners());

const listeners = eventEmitter.listeners('MyEvent');
console.log('Listeners:', listeners);

const listenerCount = eventEmitter.listenerCount('MyEvent');
console.log('Listener Count:', listenerCount);

eventEmitter.removeListener('MyEvent', myFirstEventHandler);
eventEmitter.removeAllListeners('MyEvent');

console.log()
console.log('After removing Listeners...')

const removed_listeners = eventEmitter.listeners('MyEvent');
console.log('Listeners:', removed_listeners);

const removed_listenerCount = eventEmitter.listenerCount('MyEvent');
console.log('Listener Count:', removed_listenerCount);
