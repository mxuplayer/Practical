const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

const sortArray = (arr) => {
    const sortedArray = arr.slice().sort((a, b) => a - b);
    console.log('Sorted Array:', sortedArray);
};

const reverseArray = (arr) => {
    const reversedArray = arr.slice().reverse();
    console.log('Reversed Array:', reversedArray);
};

const searchArray = (arr, target) => {
    const index = arr.indexOf(target);
    if (index !== -1) {
        console.log(`Element ${target} found at index ${index}`);
    } else {
        console.log(`Element ${target} not found in the array`);
    }
};

eventEmitter.on('sort', sortArray);
eventEmitter.on('reverse', reverseArray);
eventEmitter.on('search', searchArray);

const myArray = [5, 2, 8, 1, 7];

eventEmitter.emit('sort', myArray);
eventEmitter.emit('reverse', myArray);
eventEmitter.emit('search', myArray, 1);
eventEmitter.emit('search', myArray, 6);
