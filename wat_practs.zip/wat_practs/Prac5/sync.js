const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function showMenu() {
  console.log("\nMenu:");
  console.log("1. Read File");
  console.log("2. Write File");
  console.log("3. Append File");
  console.log("4. Rename File");
  console.log("5. Delete File");
  console.log("6. Exit");
  rl.question("Select an option (1-6): ", handleMenuChoice);
}

function handleMenuChoice(choice) {
  switch (choice) {
    case '1':
      rl.question("Enter the file name to read: ", readFile);
      break;
    case '2':
      rl.question("Enter the file name to write: ", writeFile);
      break;
    case '3':
      rl.question("Enter the file name to append: ", appendFile);
      break;
    case '4':
      rl.question("Enter the current file name: ", (currentName) => {
        rl.question("Enter the new file name: ", (newName) => {
          renameFile(currentName, newName);
        });
      });
      break;
    case '5':
      rl.question("Enter the file name to delete: ", deleteFile);
      break;
    case '6':
      rl.close();
      console.log("Program Ended");
      break;
    default:
      console.log("Invalid choice. Please enter a number from 1 to 6.");
      showMenu();
  }
}

function readFile(fileName) {
  try {
    const content = fs.readFileSync(fileName, 'utf-8');
    console.log(`Contents of ${fileName}:\n${content}`);
  } catch (err) {
    console.error(`Error reading the file: ${err.message}`);
  }
  showMenu();
}

function writeFile(fileName) {
  rl.question("Enter the content to write: ", (content) => {
    try {
      fs.writeFileSync(fileName, content);
      console.log(`File ${fileName} written successfully.`);
    } catch (err) {
      console.error(`Error writing the file: ${err.message}`);
    }
    showMenu();
  });
}

function appendFile(fileName) {
  rl.question("Enter the content to append: ", (content) => {
    try {
      fs.appendFileSync(fileName, content);
      console.log(`Content appended to ${fileName} successfully.`);
    } catch (err) {
      console.error(`Error appending to the file: ${err.message}`);
    }
    showMenu();
  });
}

function renameFile(currentName, newName) {
  try {
    fs.renameSync(currentName, newName);
    console.log(`File renamed from ${currentName} to ${newName} successfully.`);
  } catch (err) {
    console.error(`Error renaming the file: ${err.message}`);
  }
  showMenu();
}

function deleteFile(fileName) {
  try {
    fs.unlinkSync(fileName);
    console.log(`File ${fileName} deleted successfully.`);
  } catch (err) {
    console.error(`Error deleting the file: ${err.message}`);
  }
  showMenu();
}

showMenu();
